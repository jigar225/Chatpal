class Onborard {
  final String title, subtitle, lottie;

  Onborard({required this.title, required this.subtitle, required this.lottie});
}
