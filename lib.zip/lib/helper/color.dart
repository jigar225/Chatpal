import 'package:flutter/material.dart';

Color dark_blue = const Color.fromARGB(255, 1, 56, 101);
Color light_blue = const Color.fromARGB(255, 184, 219, 248);