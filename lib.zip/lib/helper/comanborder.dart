import 'package:flutter/material.dart';

OutlineInputBorder commonBorder = OutlineInputBorder(
    borderRadius: BorderRadius.circular(20),
    borderSide: const BorderSide(color: Colors.white));
