import 'package:flutter/material.dart';

const name = 'Chatpal';

late Size mq;
