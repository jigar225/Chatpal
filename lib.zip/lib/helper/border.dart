import 'package:flutter/material.dart';

OutlineInputBorder border = OutlineInputBorder(
    borderRadius: BorderRadius.circular(15),
    borderSide: BorderSide(color: const Color.fromARGB(255, 184, 219, 248)));
